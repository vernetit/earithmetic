/* ===== ui-home.js — pantalla de inicio: menú de arriba (idioma + ayuda), modo, niveles ===== */
function renderHome() {
  const levels = DISCIPLINES.mul.levels;
  const rh = S.sound === 'rhythm';
  const r = RATINGS[ratingKey('mul')] || 0, L = levelOf('mul'), prog = r - Math.floor(r);
  const last = store.get(rh ? 'lastSession_r' : 'lastSession', null);
  const fixed = Math.min(store.get('fixedLevel', L), levels.length - 1);
  const opts = levels.map((lv, i) =>
    `<option value="${i}" ${i === fixed ? 'selected' : ''}>${t('h.fixedOpt', { i: i + 1, n: lv.n, t: lv.t })}</option>`).join('');

  $('#home-body').innerHTML = `
    <div class="hbar">
      ${segHTML('h-lang', [['es', 'ES'], ['en', 'EN']], S.lang)}
      <button class="btn help" data-go="help">${t('h.help')}</button>
    </div>
    <h1>${t('app.title')}</h1>
    ${segHTML('h-mode', [['notes', t('mode.notes')], ['rhythm', t('mode.rhythm')]], S.sound, true)}
    <div class="mut modehint">${rh ? t('h.hintR', { bpm: S.bpmRit }) : t('h.hintN', { ref: noteName(S.refMidi) })}</div>
    <div class="card">
      <div class="mut">${t('h.adaptive')}</div>
      <div class="big">${levels[L].n} <span class="mut" style="font-size:.9rem">(${L + 1}/${levels.length})</span></div>
      <div class="bar"><i style="width:${Math.round(prog * 100)}%"></i></div>
      <div class="mut" style="font-size:.85rem;margin-top:4px">${t('h.ratingLine', { r: r.toFixed(2), t: levels[L].t })}</div>
      <div class="btns" style="margin-top:12px"><button class="btn pri wide" id="h-play">${t('h.play')}</button></div>
    </div>
    <div class="card">
      <div class="mut" style="margin-bottom:6px">${t('h.fixedTitle')}</div>
      <select id="h-level" style="width:100%">${opts}</select>
      <div class="btns"><button class="btn wide" id="h-fixed">${t('h.playFixed')}</button></div>
    </div>
    ${last ? `<div class="card"><div class="mut">${t('h.last', { d: fmtDate(last.ts) })}</div>
      <div>${t('h.lastLine', { ok: last.ok, n: last.n, m: fmtS(last.med) })}${last.mode === 'adapt'
        ? t('h.lastRating', { a: (+last.r0).toFixed(2), b: (+last.r1).toFixed(2) }) : ''}</div></div>` : ''}
    <div class="btns">
      <button class="btn" data-go="stats">${t('h.stats')}</button>
      <button class="btn" data-go="settings">${t('h.settings')}</button>
    </div>`;

  onSeg('h-lang', v => { S.lang = v; saveSettings(); applyI18n(); renderHome(); });
  onSeg('h-mode', v => { S.sound = v; saveSettings(); renderHome(); });
  $('#h-play').onclick = () => startGame('adapt');
  $('#h-fixed').onclick = () => {
    const v = +$('#h-level').value;
    store.set('fixedLevel', v);
    startGame('fixed', v);
  };
}
