/* ===== ui-game.js — pantalla de juego (#scr-game) en 4 niveles ===== */
/* Estado global del juego */
const G = {
  disc: 'mul',
  rk: 'mul',          // clave de rating de la sesión ('mul' notas · 'mul_r' ritmo)
  sm: 'notes',        // modo de sonido de la sesión
  mode: 'adapt',      // 'adapt' | 'fixed'
  level: 0,           // índice de nivel del problema actual
  fixedLevel: 0,
  prob: null,         // objeto P
  buf: [],            // cifras ingresadas; buf[0] = unidades (se escribe de derecha a izquierda)
  phase: 'idle',      // 'answer' | 'feedback' | 'idle'
  t0: 0,              // performance.now() en que arranca el cronómetro
  last: null,         // último resultado
  session: null,      // { n, ok, start, r0, res: [] }
  tick: null, advT: null
};

const KEYLAYOUT = [0, 1, 2, 3, 4, 'back', 5, 6, 7, 8, 9, 'enter'];

/* ---------- NIVEL 1: fila de referencia (depende del modo, se redibuja al empezar) ---------- */
function renderRefKeys() {
  let h;
  if (isRhy()) {
    h = `<button class="rk base" data-ref="A"><b>♩</b><small>${S.bpmRit}</small></button>`;
    for (let d = 0; d <= 9; d++)
      h += `<button class="rk" data-ref="${d}"><b>${d}</b><span class="rg">${rhythmSVG(rhythmOf(d))}</span></button>`;
  } else {
    h = `<button class="rk base" data-ref="A"><b>${noteShort(S.refMidi)}</b><small>ref</small></button>`;
    for (let d = 0; d <= 9; d++)
      h += `<button class="rk" data-ref="${d}"><b>${d}</b><small>${noteShort(S.digitMidi[d])}</small></button>`;
  }
  $('#lv1').innerHTML = h;
}
function bindRefKeys() {
  $('#lv1').addEventListener('pointerdown', e => {
    const b = e.target.closest('[data-ref]'); if (!b) return;
    e.preventDefault();
    const r = b.dataset.ref;
    if (r === 'A') playRefNow(); else playDigitNow(+r);
    flash(b);
  });
}

function buildKeys() {
  const el = $('#keys');
  el.innerHTML = KEYLAYOUT.map(k => typeof k === 'number'
    ? `<button class="ak" data-k="${k}" aria-label="${k}"><span class="kn">${k}</span></button>`
    : `<button class="ak fn" data-k="${k}" aria-label="${k === 'back' ? '⌫' : '⏎'}">${k === 'back' ? '⌫' : '⏎'}</button>`
  ).join('');
  el.addEventListener('pointerdown', e => {
    const b = e.target.closest('[data-k]'); if (!b) return;
    e.preventDefault();
    flash(b, 120);
    const k = b.dataset.k;
    press(/^\d$/.test(k) ? +k : k);
  });
}

function bindGame() {
  $('#g-exit').addEventListener('click', exitGame);
  $('#g-play').addEventListener('click', () => { playProblem(); });
  $('#g-pass').addEventListener('click', () => { if (G.phase === 'answer') finish(false, true); });
  // ▶ de abajo, sobre la tecla ⌫
  $('#k-play').addEventListener('pointerdown', e => { e.preventDefault(); flash(e.currentTarget, 120); playProblem(); });

  // Nivel 3: tocar casilleros con ♪ (o números en la corrección) para escuchar su cifra
  $('#lv3').addEventListener('pointerdown', e => {
    const c = e.target.closest('[data-d]'); if (!c) return;
    e.preventDefault();
    playDigitNow(+c.dataset.d); flash(c, 140);
  });

  // Nivel 4: pad de la cuenta → suena la cifra e ilumina su gemelo en el Nivel 2
  $('#pad').addEventListener('pointerdown', e => {
    const b = e.target.closest('[data-d]'); if (!b) return;
    e.preventDefault();
    playDigitNow(+b.dataset.d); flash(b, 140);
    hl(document.getElementById(`vc-${b.dataset.r}-${b.dataset.i}`));
  });

  // Botones de la línea de feedback
  $('#fb').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.act === 'next') advance();
    if (b.dataset.act === 'ans') playAnswer();
  });

  // Teclado físico
  document.addEventListener('keydown', e => {
    if (!$('#scr-game').classList.contains('on') || $('#ovl').classList.contains('on')) return;
    if (/^\d$/.test(e.key)) { press(+e.key); e.preventDefault(); }
    else if (e.key === 'Backspace') { press('back'); e.preventDefault(); }
    else if (e.key === 'Enter') { press('enter'); e.preventDefault(); }
    else if (e.key === ' ') { playProblem(); e.preventDefault(); }
    else if (e.key === 'Escape') exitGame();
  });

  window.addEventListener('resize', () => { if (G.prob && $('#scr-game').classList.contains('on')) renderGame(); });
}

/* ---------- flujo ---------- */
function startGame(mode, fixedLevel) {
  audioInit();
  G.mode = mode;
  G.fixedLevel = fixedLevel || 0;
  G.sm = S.sound;
  G.rk = ratingKey(G.disc);
  G.session = { n: 0, ok: 0, start: Date.now(), r0: RATINGS[G.rk] || 0, res: [] };
  $('#ovl').classList.remove('on');
  renderRefKeys();
  show('game');
  nextProblem();
}

function nextProblem() {
  clearTimeout(G.advT); stopSeq();
  const len = +S.sessionLen;
  if (len && G.session.n >= len) { endSession(); return; }
  const levels = DISCIPLINES[G.disc].levels;
  G.level = G.mode === 'adapt' ? levelOf(G.disc) : G.fixedLevel;
  G.prob = levels[G.level].g();
  G.buf = [];
  G.phase = 'answer';
  G.last = null;
  renderGame();
  let delay = 0;
  if (S.autoPlay) delay = playProblem();
  G.t0 = performance.now() + delay;
  startTick();
}

function press(k) {
  if (G.phase === 'feedback') { if (k === 'enter') advance(); return; }
  if (G.phase !== 'answer') return;
  const p = G.prob;
  if (typeof k === 'number') {
    if (G.buf.length >= p.maxLen) return;
    G.buf.push(k);
    if (S.keySound) playDigitNow(k);
    renderReg();
    if (S.autoJudge && G.buf.length === p.maxLen) finish(isCorrect());
  } else if (k === 'back') {
    G.buf.pop(); renderReg();
  } else if (k === 'enter') {
    if (!G.buf.length) return;
    finish(isCorrect());
  }
}

function isCorrect() {
  if (!G.buf.length) return false;
  const s = G.buf.slice().reverse().join('');
  return BigInt(s) === G.prob.ans;
}

function finish(ok, passed) {
  if (G.phase !== 'answer') return;
  stopTick();
  const secs = Math.max(0, (performance.now() - G.t0) / 1000);
  G.phase = 'feedback';
  const levels = DISCIPLINES[G.disc].levels;
  const res = { ok: !!ok && !passed, passed: !!passed, secs };
  if (G.mode === 'adapt') {
    RATINGS[G.rk] = nextRating(RATINGS[G.rk] || 0, res, levels);
    saveRatings();
  }
  const p = G.prob;
  HIST.push({
    ts: Date.now(), d: G.disc, sm: G.sm === 'rhythm' ? 'r' : 'n', m: G.mode, l: G.level,
    q: p.view.top + '×' + p.view.bot, a: p.ansStr,
    u: G.buf.slice().reverse().join(''),
    ok: res.ok, p: res.passed, s: Math.round(secs * 10) / 10,
    r: RATINGS[G.rk] || 0
  });
  saveHist();
  G.session.n++; if (res.ok) G.session.ok++;
  G.session.res.push(res);
  G.last = res;
  if (S.fbSound) sfx(res.ok);
  renderGame();
  if (res.ok) G.advT = setTimeout(advance, +S.advanceMs);
  else if (!S.wrongWait) G.advT = setTimeout(advance, +S.advanceMs * 2.5);
}

function advance() {
  if (G.phase !== 'feedback') return;
  clearTimeout(G.advT);
  nextProblem();
}

function exitGame() {
  clearTimeout(G.advT); stopTick(); stopSeq();
  G.phase = 'idle';
  $('#ovl').classList.remove('on');
  show('home');
}

function endSession() {
  stopTick(); stopSeq();
  G.phase = 'idle';
  const s = G.session, levels = DISCIPLINES[G.disc].levels;
  const okT = s.res.filter(r => r.ok).map(r => r.secs);
  const r1 = RATINGS[G.rk] || 0;
  const lv = r => levels[Math.min(Math.floor(r), levels.length - 1)].n;
  store.set(G.sm === 'rhythm' ? 'lastSession_r' : 'lastSession',
    { ts: Date.now(), n: s.n, ok: s.ok, med: median(okT), r0: s.r0, r1, mode: G.mode });
  $('#ovl-body').innerHTML = `
    <h2>${t('end.title')}</h2>
    <div class="kpis">
      <div><b>${s.ok}/${s.n}</b><span>${t('end.correct')}</span></div>
      <div><b>${fmtS(median(okT))}</b><span>${t('end.median')}</span></div>
      <div><b>${G.mode === 'adapt' ? lv(r1) : levels[G.fixedLevel].n}</b><span>${t('end.level')}</span></div>
    </div>
    ${G.mode === 'adapt' ? `<p class="mut">${t('end.rating', { a: s.r0.toFixed(2), b: r1.toFixed(2), la: lv(s.r0), lb: lv(r1) })}</p>` : ''}
    <div class="btns"><button class="btn pri" id="ovl-again">${t('end.again')}</button><button class="btn" id="ovl-home">${t('end.home')}</button></div>`;
  $('#ovl').classList.add('on');
  $('#ovl-again').onclick = () => startGame(G.mode, G.fixedLevel);
  $('#ovl-home').onclick = exitGame;
}

/* ---------- cronómetro ---------- */
function startTick() {
  stopTick();
  const el = $('#g-time'), t = DISCIPLINES[G.disc].levels[G.level].t;
  G.tick = setInterval(() => {
    const s = Math.max(0, (performance.now() - G.t0) / 1000);
    el.textContent = s < 60 ? s.toFixed(1) : fmtS(s);
    el.classList.toggle('late', s > t);
  }, 200);
}
function stopTick() { clearInterval(G.tick); G.tick = null; }

/* ---------- reproducción ---------- */
/* Toca: referencia (nota o conteo) · cifras del factor superior · 2 unidades de silencio · cifras del inferior.
   Devuelve ms. En modo ritmo la unidad es un pulso de negra y cada cifra dura lo que dura su ritmo. */
function playProblem() {
  const p = G.prob; if (!p) return 0;
  const items = refItems();
  [...p.view.top].forEach((c, i) => items.push(digitItem(+c, `vc-t-${i}`)));
  items.push(...sepItems());
  [...p.view.bot].forEach((c, i) => items.push(digitItem(+c, `vc-b-${i}`)));
  return playSeq(items, unitMs(), (it, ms) => { if (it.id) hl(document.getElementById(it.id), ms * 0.85); });
}
function playAnswer() {
  const p = G.prob; if (!p) return;
  const items = refItems();
  [...p.ansStr].forEach(c => items.push(digitItem(+c)));
  playSeq(items, unitMs());
}

/* ---------- render ---------- */
function cellSize(cols) {
  const w = Math.min(window.innerWidth, 560) - 20;
  return Math.max(15, Math.min(34, Math.floor(w / cols) - 3));
}

function renderGame() {
  const p = G.prob, levels = DISCIPLINES[G.disc].levels;
  const C = p.maxLen + 1;
  const cw = cellSize(C) + 'px';
  $('#lv2').style.setProperty('--cw', cw);
  $('#lv3').style.setProperty('--cw', cw);
  const len = +S.sessionLen;
  $('#g-lvl').textContent = levels[G.level].n + (G.mode === 'fixed' ? t('g.fixed') : '');
  $('#g-count').textContent = (G.session.n + (G.phase === 'answer' ? 1 : 0)) + (len ? '/' + len : '');
  $('#g-pass').disabled = G.phase !== 'answer';
  $('#keys').classList.toggle('nums', !!S.keyNums);
  $('#lv2').innerHTML = vCells();
  renderReg();
  renderPad();
  renderFb();
  if (G.phase !== 'answer') {
    const el = $('#g-time');
    if (G.last) { el.textContent = G.last.secs < 60 ? G.last.secs.toFixed(1) : fmtS(G.last.secs); }
  } else { $('#g-time').textContent = '0.0'; $('#g-time').classList.remove('late'); }
}

/* NIVEL 2: esquema espacial de la cuenta con cuadrados blancos (pasivo) */
function vCells() {
  const p = G.prob, a = p.view.top, b = p.view.bot, C = p.maxLen + 1, fb = G.phase === 'feedback';
  let h = '';
  for (let j = 0; j < a.length; j++)
    h += `<div class="vc" id="vc-t-${j}" style="grid-column:${C - a.length + j + 1};grid-row:1">${fb ? a[j] : ''}</div>`;
  h += `<div class="vop" style="grid-column:1;grid-row:2">${p.view.op}</div>`;
  for (let j = 0; j < b.length; j++)
    h += `<div class="vc" id="vc-b-${j}" style="grid-column:${C - b.length + j + 1};grid-row:2">${fb ? b[j] : ''}</div>`;
  h += `<div class="vline" style="grid-column:1 / span ${C};grid-row:3"></div>`;
  return `<div class="vgrid" style="grid-template-columns:repeat(${C},var(--cw));grid-template-rows:var(--cw) var(--cw) 8px">${h}</div>`;
}

/* NIVEL 3: registro de derecha a izquierda */
function renderReg() {
  const p = G.prob, C = p.maxLen + 1, el = $('#lv3');
  if (G.phase === 'feedback' && G.last && !G.last.ok) { el.innerHTML = compareHTML(G.buf, p.ansStr, p.maxLen); return; }
  const fbOk = G.phase === 'feedback';
  let h = `<div class="rlab" style="grid-column:1;grid-row:1">=</div>`;
  for (let pos = 0; pos < p.maxLen; pos++) {
    const d = G.buf[pos], has = d !== undefined;
    const cur = G.phase === 'answer' && pos === G.buf.length;
    const cls = 'rc' + (has ? ' full' : '') + (cur ? ' cur' : '') + (fbOk && has ? ' num good' : '');
    h += `<button class="${cls}" style="grid-column:${C - pos};grid-row:1" ${has ? `data-d="${d}"` : ''} tabindex="-1">${has ? (fbOk ? d : '♪') : ''}</button>`;
  }
  el.innerHTML = `<div class="vgrid" style="grid-template-columns:repeat(${C},var(--cw));grid-auto-rows:var(--cw)">${h}</div>`;
}

/* Comparación tras un error: fila "vos" y fila "bien", diferencias con borde rojo, todo tocable */
function compareHTML(buf, ansStr, maxLen) {
  const C = maxLen + 1, cr = [...ansStr].reverse();
  let h = `<div class="rlab" style="grid-column:1;grid-row:1">${t('g.you')}</div><div class="rlab" style="grid-column:1;grid-row:2">${t('g.right')}</div>`;
  for (let pos = 0; pos < maxLen; pos++) {
    const u = buf[pos], c = cr[pos];
    const diff = (u === undefined ? 0 : u) !== (c === undefined ? 0 : +c) || (u === undefined && c !== undefined);
    const col = C - pos;
    const mark = (u === undefined && c === undefined) ? '' : (diff ? ' diff' : ' good');
    h += `<button class="rc num${u !== undefined ? ' full' : ''}${mark}" style="grid-column:${col};grid-row:1" ${u !== undefined ? `data-d="${u}"` : ''} tabindex="-1">${u !== undefined ? u : ''}</button>`;
    h += `<button class="rc num${c !== undefined ? ' full' : ''}" style="grid-column:${col};grid-row:2" ${c !== undefined ? `data-d="${c}"` : ''} tabindex="-1">${c !== undefined ? c : ''}</button>`;
  }
  return `<div class="vgrid" style="grid-template-columns:repeat(${C},var(--cw));grid-auto-rows:var(--cw)">${h}</div>`;
}

/* NIVEL 4a: pad de la cuenta (botones blancos vacíos, alineados como la cuenta).
   Comparte el ancho con el ▶ de la derecha, que ocupa una columna del teclado (justo sobre ⌫). */
function renderPad() {
  const p = G.prob, a = p.view.top, b = p.view.bot, W = Math.max(a.length, b.length);
  const showN = S.padNums || G.phase === 'feedback';
  const tw = Math.min(window.innerWidth - 12, 520);   // ancho útil del nivel 4
  const avail = tw - (tw - 30) / 6 - 6;               // menos la columna del ▶ y su separación
  const opW = 22;
  const bw = Math.max(24, Math.min(64, Math.floor((avail - opW - 5 * W) / W)));
  let h = '';
  for (let j = 0; j < a.length; j++)
    h += `<button class="pk" data-r="t" data-i="${j}" data-d="${a[j]}" style="grid-column:${W - a.length + j + 2};grid-row:1">${showN ? a[j] : ''}</button>`;
  h += `<div class="padop" style="grid-column:1;grid-row:2">${p.view.op}</div>`;
  for (let j = 0; j < b.length; j++)
    h += `<button class="pk" data-r="b" data-i="${j}" data-d="${b[j]}" style="grid-column:${W - b.length + j + 2};grid-row:2">${showN ? b[j] : ''}</button>`;
  const el = $('#pad');
  el.style.gridTemplateColumns = `${opW}px repeat(${W},${bw}px)`;
  el.innerHTML = h;
}

/* Línea de feedback */
function renderFb() {
  const el = $('#fb');
  el.className = 'fb';
  if (G.phase !== 'feedback' || !G.last) {
    el.innerHTML = `<span class="mut">${t('g.hint')}</span>`;
    return;
  }
  const r = G.last, tt = DISCIPLINES[G.disc].levels[G.level].t;
  const btns = `<button data-act="ans">${t('g.ans')}</button><button class="go" data-act="next">${t('g.next')}</button>`;
  if (r.ok) {
    el.classList.add('good');
    el.innerHTML = `<span>${t('g.ok', { s: fmtS(r.secs) })}${r.secs > tt ? t('g.slow') : ''}</span>${btns}`;
  } else {
    el.classList.add('bad');
    el.innerHTML = `<span>${r.passed ? t('g.passed') : t('g.wrong')}${t('g.was', { a: G.prob.ansStr })}</span>${btns}`;
  }
}
