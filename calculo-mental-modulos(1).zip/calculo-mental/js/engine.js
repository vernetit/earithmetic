/* ===== engine.js — generador de problemas, niveles y rating adaptativo ===== */
const rnd = n => Math.floor(Math.random() * n);

/* Número aleatorio de `len` cifras como string (sin cero inicial; los de 1 cifra van de 2 a 9) */
function randDigits(len) {
  let s = len === 1 ? String(2 + rnd(8)) : String(1 + rnd(9));
  for (let i = 1; i < len; i++) s += rnd(10);
  return s;
}

/* Objeto problema genérico */
function P(o) {
  return Object.assign({ view: null, ops: [], ans: 0n, ansStr: '0', kind: '', maxLen: 1 }, o);
}

/* Multiplicación a×b cifras, aritmética con BigInt */
function genMul(a, b) {
  const x = randDigits(a), y = randDigits(b);
  const ans = BigInt(x) * BigInt(y);
  return P({ kind: 'mul', view: { top: x, bot: y, op: '×' }, ops: [BigInt(x), BigInt(y)],
             ans, ansStr: ans.toString(), maxLen: a + b, a, b });
}

/* Niveles 1×1 … 8×8 (a ≥ b), ordenados por cantidad de productos parciales (a·b) */
function buildMulLevels() {
  const L = [];
  for (let a = 1; a <= 8; a++) for (let b = 1; b <= a; b++) L.push({ a, b });
  L.sort((p, q) => (p.a * p.b - q.a * q.b) || (p.a + p.b - q.a - q.b) || (q.a - p.a));
  return L.map(({ a, b }) => ({
    n: a + '×' + b,
    t: Math.round(8 + a * b * 6),   // segundos objetivo (el cronómetro arranca al terminar de sonar)
    g: () => genMul(a, b),
    a, b
  }));
}

const DISCIPLINES = {
  mul: { name: 'Multiplicación', levels: buildMulLevels() }
};

/* Cada modo de sonido lleva su propio rating: 'mul' (notas) y 'mul_r' (ritmo) */
function ratingKey(disc) { return disc + (S.sound === 'rhythm' ? '_r' : ''); }

/* Rating = índice de nivel + progreso (0–0,99).
   +0,25 acierto en tiempo · +0,08 acierto lento (≤2×) · −0,1 muy lento · −0,5 error o pasar.
   Al cambiar de nivel se entra a la mitad (x,5). */
function nextRating(r, res, levels) {
  const L = Math.floor(r), max = levels.length - 1;
  const t = levels[Math.min(L, max)].t;
  let d;
  if (res.passed || !res.ok) d = -0.5;
  else if (res.secs <= t) d = 0.25;
  else if (res.secs <= 2 * t) d = 0.08;
  else d = -0.1;
  let nr = r + d;
  if (nr < 0) nr = 0;
  let nL = Math.floor(nr);
  if (nL > max) { nL = max; nr = max + 0.99; }
  if (nL !== L) nr = nL + 0.5;
  if (nr > max + 0.99) nr = max + 0.99;
  return Math.round(nr * 1000) / 1000;
}

function levelOf(disc) {
  return Math.min(Math.floor(RATINGS[ratingKey(disc)] || 0), DISCIPLINES[disc].levels.length - 1);
}
