/* ===== i18n.js — textos en español e inglés, nombres de notas e intervalos ===== */
/* t('clave', {var}) busca en el idioma de S.lang; si falta, en español; si falta, devuelve la clave.
   Las entradas pueden ser texto con {var} o funciones (v) => texto. */
const I18N = {
  es: {
    'doc.title': 'Cálculo mental · Notas y ritmo',
    'locale': 'es-AR',
    'app.title': 'Cálculo mental',
    'mode.notes': '♪ Notas',
    'mode.rhythm': '🥁 Ritmo',
    'nav.home': '← Inicio',
    'nav.stats': 'Estadísticas',
    'nav.settings': 'Configuración',
    'help.title': 'Cómo se juega',
    'h.help': '? Ayuda',
    'h.hintN': 'Cada cifra es una nota; la referencia es {ref}.',
    'h.hintR': 'Cada cifra es un ritmo de un pulso de negra ({bpm} bpm).',
    'h.adaptive': 'Multiplicación · nivel adaptativo',
    'h.ratingLine': 'Rating {r} · objetivo {t} s por cuenta',
    'h.play': '▶ Jugar',
    'h.fixedTitle': 'Nivel fijo (no mueve el rating)',
    'h.fixedOpt': '{i}. {n} · objetivo {t} s',
    'h.playFixed': 'Jugar este nivel',
    'h.last': 'Última sesión · {d}',
    'h.lastLine': '{ok}/{n} aciertos · mediana {m}',
    'h.lastRating': ' · rating {a} → {b}',
    'h.stats': '📊 Estadísticas',
    'h.settings': '⚙ Configuración',
    'g.exit': 'Salir',
    'g.play': 'Tocar la cuenta',
    'g.pass': 'Pasar',
    'g.fixed': ' (fijo)',
    'g.hint': '← de derecha a izquierda · ⏎ corrige',
    'g.ok': '✔ Bien · {s}',
    'g.slow': ' (lento)',
    'g.passed': '↷ Pasaste',
    'g.wrong': '✘ No',
    'g.was': ' · era {a}',
    'g.ans': '▶ resultado',
    'g.next': 'Seguir ⏎',
    'g.you': 'vos',
    'g.right': 'bien',
    'end.title': 'Fin de la sesión',
    'end.correct': 'aciertos',
    'end.median': 'mediana acierto',
    'end.level': 'nivel',
    'end.rating': 'Rating: {a} → {b} ({la} → {lb})',
    'end.again': 'Otra sesión',
    'end.home': 'Inicio',
    's.none': 'Todavía no jugaste ninguna cuenta en este modo.',
    's.problems': 'cuentas',
    's.correct': 'aciertos',
    's.time': 'tiempo total',
    's.ratingT': 'Rating (modo adaptativo)',
    's.barsT': 'Aciertos por nivel',
    's.byLevel': 'Por nivel',
    's.last20': 'Últimas 20',
    's.thLevel': 'Nivel', 's.thRight': 'Bien', 's.thMedian': 'Mediana', 's.thBest': 'Mejor', 's.thTarget': 'Obj.',
    's.thDate': 'Fecha', 's.thProb': 'Cuenta', 's.thYou': 'Vos', 's.thAns': 'Era', 's.thTime': 'Tiempo',
    's.passed': 'pasó',
    's.notEnough': 'Todavía no hay suficientes datos.',
    's.noData': 'Sin datos.',
    's.exp': '⬇ Exportar JSON',
    's.imp': '⬆ Importar JSON',
    's.del': '🗑 Borrar todo',
    's.delConfirm': '¿Borrar historial y rating de los dos modos? No se puede deshacer.',
    's.impConfirm': '¿Importar {n} cuentas y reemplazar los datos actuales?',
    's.impBad': 'El archivo no es una exportación válida.',
    'set.test': '🔊 Probar sonido',
    'set.reset': 'Restablecer',
    'set.resetConfirm': '¿Volver a la configuración por defecto? (incluye notas y ritmos)',
    'sec.general': 'General',
    'set.lang': 'Idioma',
    'set.sound': 'Modo de sonido',
    'sec.sound': 'Sonido y melodía',
    'set.vol': 'Volumen',
    'set.bpmMel': 'Velocidad de la melodía',
    'set.noteMs': 'Duración de cada nota',
    'set.autoPlay': 'Tocar la cuenta al empezar cada problema',
    'set.playBase': 'Modo notas: tocar la referencia antes de la cuenta',
    'set.keySound': 'Sonar la cifra al escribirla',
    'set.fbSound': 'Sonido de acierto / error',
    'sec.rhythm': 'Ritmo',
    'set.bpmRit': 'Velocidad del ritmo',
    'set.countIn': 'Clicks de conteo antes de la cuenta',
    'set.accentBeat': 'Acentuar el primer golpe de cada pulso',
    'set.beatClick': 'Click suave en cada pulso',
    'set.rhythmPitch': 'Tocar los golpes con la nota de cada cifra',
    'sec.notesMap': 'Notas por cifra',
    'set.notesReset': 'Restaurar notas',
    'set.dup': '⚠ Suenan igual: {list}',
    'sec.rhyMap': 'Ritmos por cifra',
    'set.rhyHelp': '<b>x</b> = golpe · <b>X</b> = golpe con acento · <b>-</b> = silencio. Los signos de un grupo se reparten el tiempo en partes iguales (<b>xxx</b> = tresillo). La coma divide el pulso en partes iguales (<b>xxx,xxxx</b> = tresillo de semicorcheas + 4 fusas). El espacio suma otro pulso (<b>x xx</b> dura dos negras).',
    'set.rhyReset': 'Restaurar ritmos',
    'sec.visual': 'Ayudas visuales',
    'set.padNums': 'Mostrar números en el pad de la cuenta',
    'set.keyNums': 'Mostrar números en el teclado de respuesta',
    'sec.game': 'Juego',
    'set.autoJudge': 'Corregir solo al llenar todas las casillas',
    'set.advanceMs': 'Pausa después de un acierto',
    'set.wrongWait': 'Después de un error, esperar a que toque "Seguir"',
    'set.sessionLen': 'Problemas por sesión',
    'opt.unlimited': 'Sin límite',
    't.digit': 'Cifra', 't.note': 'Nota', 't.interval': 'Intervalo', 't.rhythm': 'Ritmo', 't.code': 'Código', 't.name': 'Nombre',
    't.custom': 'personalizado',
    'rn.0': 'silencio de negra', 'rn.1': 'negra', 'rn.2': '2 corcheas', 'rn.3': 'tresillo de corcheas',
    'rn.4': '4 semicorcheas', 'rn.5': 'quintillo', 'rn.6': 'seisillo de semicorcheas', 'rn.7': 'septillo',
    'rn.8': '8 fusas', 'rn.9': 'tresillo de semicorcheas + 4 fusas',
    'help.body': v => `
<div class="card help">
  <h2>La idea</h2>
  <p>Multiplicás de memoria <b>sin ver los números</b>: cada cifra se <b>escucha</b>. En la pantalla de inicio elegís el modo:</p>
  <p><b>♪ Notas</b>: cada cifra es una nota, que comparás con una nota de referencia.<br>
  <b>🥁 Ritmo</b>: cada cifra es un ritmo que dura un pulso de negra.</p>
  <p>Cada modo tiene su propio nivel adaptativo y sus propias estadísticas.</p>
</div>
<div class="card help">
  <h2>Paso a paso</h2>
  <ol>
    <li>Tocá <b>▶ Jugar</b> (nivel adaptativo) o elegí un <b>nivel fijo</b>.</li>
    <li>Escuchá la cuenta: primero la referencia (la nota de referencia, o el conteo en modo ritmo), después las cifras del número de arriba, un silencio y las cifras del número de abajo.</li>
    <li>Hacé la cuenta y escribí el resultado <b>de derecha a izquierda</b>, empezando por las unidades.</li>
    <li>Se corrige solo cuando llenás todos los casilleros. Si el resultado tiene menos cifras, apretá <b>⏎</b>.</li>
    <li>Al corregir aparecen los números. Si te equivocaste, ves tu respuesta (<b>vos</b>) arriba de la correcta (<b>bien</b>), con las cifras distintas en rojo.</li>
  </ol>
  <p>Para volver a escuchar la cuenta: <b>▶</b> arriba a la derecha, o el <b>▶</b> que está sobre la tecla ⌫.</p>
</div>
<div class="card help">
  <h2>La pantalla de juego</h2>
  <p><b>1 · Fila de referencia</b> (arriba): cada cifra con su nota o su ritmo a la vista. Tocala para escucharla y comparar. La primera tecla toca la referencia (o 4 clicks al tempo del ritmo).<br>
  <b>2 · Cuadrados blancos</b>: dónde está cada cifra de la cuenta. No se tocan; se iluminan cuando suena su cifra.<br>
  <b>3 · Casilleros ♪</b>: tu respuesta. Tocá uno para escuchar lo que pusiste.<br>
  <b>4 · Pad</b>: la cuenta en botones vacíos; cada uno toca su cifra. A la derecha, <b>▶</b> repite toda la cuenta.<br>
  <b>Teclado blanco</b>: 0 1 2 3 4 ⌫ arriba, 5 6 7 8 9 ⏎ abajo (sin números, salvo que los actives).</p>
</div>
<div class="card help">
  <h2>♪ Código de notas</h2>
  <p class="mut small">Así está ahora. Se cambia en Configuración → Notas por cifra.</p>
  ${v.notes}
</div>
<div class="card help">
  <h2>🥁 Código de ritmos</h2>
  <p>Cada cifra dura un pulso de negra (${v.bpm} bpm). El primer golpe de cada pulso suena más fuerte; así se distingue <b>1 1</b> (dos negras) de <b>2</b> (dos corcheas). El <b>0</b> es un silencio de negra marcado con un golpe sordo y grave. Antes de la cuenta suenan ${v.count} clicks de conteo, y entre el número de arriba y el de abajo hay 2 pulsos de silencio sin marcar.</p>
  <p class="mut small">Se cambia en Configuración → Ritmos por cifra.</p>
  ${v.rhythms}
</div>
<div class="card help">
  <h2>Nivel adaptativo</h2>
  <p>Hay niveles desde 1×1 hasta 8×8 cifras. Si acertás dentro del tiempo objetivo, el rating sube; si te equivocás o pasás, baja. El cronómetro arranca cuando termina de sonar la cuenta.</p>
</div>
<div class="card help">
  <h2>Configuración</h2>
  <p>Ahí cambiás la velocidad de la melodía y la del ritmo (bpm), qué nota toca cada cifra y qué ritmo tiene cada cifra.</p>
  <p><b>Cómo se escribe un ritmo</b>: <code>x</code> = golpe, <code>X</code> = golpe con acento, <code>-</code> = silencio. Los signos de un grupo se reparten el pulso en partes iguales: <code>xxx</code> = tresillo. La coma divide el pulso en partes iguales: <code>xxx,xxxx</code> = tresillo de semicorcheas + 4 fusas. El espacio suma otro pulso: <code>x xx</code> dura dos negras.</p>
</div>
<div class="card help">
  <h2>Teclado de la compu</h2>
  <p>Números para escribir, Retroceso para borrar, Enter para corregir o seguir, Espacio para tocar la cuenta y Esc para salir.</p>
</div>`
  },

  en: {
    'doc.title': 'Mental math · Notes & rhythm',
    'locale': 'en-GB',
    'app.title': 'Mental math',
    'mode.notes': '♪ Notes',
    'mode.rhythm': '🥁 Rhythm',
    'nav.home': '← Home',
    'nav.stats': 'Statistics',
    'nav.settings': 'Settings',
    'help.title': 'How to play',
    'h.help': '? Help',
    'h.hintN': 'Each digit is a note; the reference is {ref}.',
    'h.hintR': 'Each digit is a one-beat rhythm ({bpm} bpm).',
    'h.adaptive': 'Multiplication · adaptive level',
    'h.ratingLine': 'Rating {r} · target {t} s per problem',
    'h.play': '▶ Play',
    'h.fixedTitle': 'Fixed level (rating unchanged)',
    'h.fixedOpt': '{i}. {n} · target {t} s',
    'h.playFixed': 'Play this level',
    'h.last': 'Last session · {d}',
    'h.lastLine': '{ok}/{n} correct · median {m}',
    'h.lastRating': ' · rating {a} → {b}',
    'h.stats': '📊 Statistics',
    'h.settings': '⚙ Settings',
    'g.exit': 'Exit',
    'g.play': 'Play the problem',
    'g.pass': 'Skip',
    'g.fixed': ' (fixed)',
    'g.hint': '← right to left · ⏎ checks',
    'g.ok': '✔ Right · {s}',
    'g.slow': ' (slow)',
    'g.passed': '↷ Skipped',
    'g.wrong': '✘ Wrong',
    'g.was': ' · it was {a}',
    'g.ans': '▶ answer',
    'g.next': 'Next ⏎',
    'g.you': 'you',
    'g.right': 'right',
    'end.title': 'Session over',
    'end.correct': 'correct',
    'end.median': 'median (correct)',
    'end.level': 'level',
    'end.rating': 'Rating: {a} → {b} ({la} → {lb})',
    'end.again': 'Another session',
    'end.home': 'Home',
    's.none': 'You haven\'t played any problem in this mode yet.',
    's.problems': 'problems',
    's.correct': 'correct',
    's.time': 'total time',
    's.ratingT': 'Rating (adaptive mode)',
    's.barsT': 'Correct by level',
    's.byLevel': 'By level',
    's.last20': 'Last 20',
    's.thLevel': 'Level', 's.thRight': 'Right', 's.thMedian': 'Median', 's.thBest': 'Best', 's.thTarget': 'Target',
    's.thDate': 'Date', 's.thProb': 'Problem', 's.thYou': 'You', 's.thAns': 'Answer', 's.thTime': 'Time',
    's.passed': 'skipped',
    's.notEnough': 'Not enough data yet.',
    's.noData': 'No data.',
    's.exp': '⬇ Export JSON',
    's.imp': '⬆ Import JSON',
    's.del': '🗑 Delete all',
    's.delConfirm': 'Delete history and rating for both modes? This cannot be undone.',
    's.impConfirm': 'Import {n} problems and replace the current data?',
    's.impBad': 'The file is not a valid export.',
    'set.test': '🔊 Test sound',
    'set.reset': 'Reset',
    'set.resetConfirm': 'Restore default settings? (includes notes and rhythms)',
    'sec.general': 'General',
    'set.lang': 'Language',
    'set.sound': 'Sound mode',
    'sec.sound': 'Sound and melody',
    'set.vol': 'Volume',
    'set.bpmMel': 'Melody tempo',
    'set.noteMs': 'Note length',
    'set.autoPlay': 'Play the problem when it starts',
    'set.playBase': 'Notes mode: play the reference before the problem',
    'set.keySound': 'Sound each digit as you type it',
    'set.fbSound': 'Right / wrong sound',
    'sec.rhythm': 'Rhythm',
    'set.bpmRit': 'Rhythm tempo',
    'set.countIn': 'Count-in clicks before the problem',
    'set.accentBeat': 'Accent the first hit of each beat',
    'set.beatClick': 'Soft click on every beat',
    'set.rhythmPitch': 'Play the hits with each digit\'s note',
    'sec.notesMap': 'Notes per digit',
    'set.notesReset': 'Restore notes',
    'set.dup': '⚠ Same pitch: {list}',
    'sec.rhyMap': 'Rhythms per digit',
    'set.rhyHelp': '<b>x</b> = hit · <b>X</b> = accented hit · <b>-</b> = rest. The signs of a group share its time equally (<b>xxx</b> = triplet). A comma splits the beat into equal parts (<b>xxx,xxxx</b> = sixteenth triplet + 4 thirty-seconds). A space adds another beat (<b>x xx</b> lasts two quarter notes).',
    'set.rhyReset': 'Restore rhythms',
    'sec.visual': 'Visual aids',
    'set.padNums': 'Show numbers on the problem pad',
    'set.keyNums': 'Show numbers on the answer keyboard',
    'sec.game': 'Game',
    'set.autoJudge': 'Check automatically when all boxes are filled',
    'set.advanceMs': 'Pause after a right answer',
    'set.wrongWait': 'After a mistake, wait for "Next"',
    'set.sessionLen': 'Problems per session',
    'opt.unlimited': 'Unlimited',
    't.digit': 'Digit', 't.note': 'Note', 't.interval': 'Interval', 't.rhythm': 'Rhythm', 't.code': 'Code', 't.name': 'Name',
    't.custom': 'custom',
    'rn.0': 'quarter rest', 'rn.1': 'quarter note', 'rn.2': '2 eighths', 'rn.3': 'eighth triplet',
    'rn.4': '4 sixteenths', 'rn.5': 'quintuplet', 'rn.6': 'sixteenth sextuplet', 'rn.7': 'septuplet',
    'rn.8': '8 thirty-seconds', 'rn.9': 'sixteenth triplet + 4 thirty-seconds',
    'help.body': v => `
<div class="card help">
  <h2>The idea</h2>
  <p>You multiply in your head <b>without seeing the numbers</b>: every digit is <b>heard</b>. Pick the mode on the home screen:</p>
  <p><b>♪ Notes</b>: each digit is a note, heard against a reference note.<br>
  <b>🥁 Rhythm</b>: each digit is a rhythm that lasts one quarter-note beat.</p>
  <p>Each mode keeps its own adaptive level and its own statistics.</p>
</div>
<div class="card help">
  <h2>Step by step</h2>
  <ol>
    <li>Tap <b>▶ Play</b> (adaptive level) or choose a <b>fixed level</b>.</li>
    <li>Listen to the problem: first the reference (the reference note, or the count-in in rhythm mode), then the digits of the top number, a pause, and the digits of the bottom number.</li>
    <li>Work it out and type the answer <b>from right to left</b>, starting with the units.</li>
    <li>It is checked automatically when every box is filled. If the answer has fewer digits, press <b>⏎</b>.</li>
    <li>After checking, the numbers appear. If you got it wrong, your answer (<b>you</b>) is shown above the right one (<b>right</b>), with the differing digits in red.</li>
  </ol>
  <p>To hear the problem again: <b>▶</b> at the top right, or the <b>▶</b> above the ⌫ key.</p>
</div>
<div class="card help">
  <h2>The game screen</h2>
  <p><b>1 · Reference row</b> (top): every digit with its note or rhythm shown. Tap to hear it and compare. The first key plays the reference (or 4 clicks at the rhythm tempo).<br>
  <b>2 · White squares</b>: where each digit of the problem is. Not tappable; they light up when their digit sounds.<br>
  <b>3 · ♪ boxes</b>: your answer. Tap one to hear what you typed.<br>
  <b>4 · Pad</b>: the problem as blank buttons; each one plays its digit. On the right, <b>▶</b> replays the whole problem.<br>
  <b>White keyboard</b>: 0 1 2 3 4 ⌫ on top, 5 6 7 8 9 ⏎ below (no numbers unless you turn them on).</p>
</div>
<div class="card help">
  <h2>♪ Note code</h2>
  <p class="mut small">Current setup. Change it in Settings → Notes per digit.</p>
  ${v.notes}
</div>
<div class="card help">
  <h2>🥁 Rhythm code</h2>
  <p>Each digit lasts one quarter-note beat (${v.bpm} bpm). The first hit of each beat is louder, so <b>1 1</b> (two quarters) sounds different from <b>2</b> (two eighths). <b>0</b> is a quarter rest marked by a low, dull thud. Before the problem you hear ${v.count} count-in clicks, and there are 2 unmarked silent beats between the top and the bottom number.</p>
  <p class="mut small">Change it in Settings → Rhythms per digit.</p>
  ${v.rhythms}
</div>
<div class="card help">
  <h2>Adaptive level</h2>
  <p>Levels go from 1×1 to 8×8 digits. A right answer within the target time raises the rating; a mistake or a skip lowers it. The timer starts when the problem has finished playing.</p>
</div>
<div class="card help">
  <h2>Settings</h2>
  <p>There you change the melody and rhythm tempos (bpm), which note each digit plays and which rhythm each digit has.</p>
  <p><b>Writing a rhythm</b>: <code>x</code> = hit, <code>X</code> = accented hit, <code>-</code> = rest. The signs of a group share the beat equally: <code>xxx</code> = triplet. A comma splits the beat into equal parts: <code>xxx,xxxx</code> = sixteenth triplet + 4 thirty-seconds. A space adds another beat: <code>x xx</code> lasts two quarter notes.</p>
</div>
<div class="card help">
  <h2>Computer keyboard</h2>
  <p>Digits to type, Backspace to delete, Enter to check or continue, Space to play the problem, Esc to exit.</p>
</div>`
  }
};

function t(k, v) {
  const D = I18N[S.lang] || I18N.es;
  let s = D[k];
  if (s == null) s = I18N.es[k];
  if (s == null) return k;
  if (typeof s === 'function') return s(v || {});
  return v ? s.replace(/\{(\w+)\}/g, (m, p) => v[p] != null ? v[p] : m) : s;
}

/* Nombres de notas: notación latina en español, letras en inglés. Octava científica (La3 = 220 Hz). */
const NOTE_NAMES = {
  es: ['Do', 'Do#', 'Re', 'Re#', 'Mi', 'Fa', 'Fa#', 'Sol', 'Sol#', 'La', 'La#', 'Si'],
  en: ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
};
function noteShort(m) { return (NOTE_NAMES[S.lang] || NOTE_NAMES.es)[((m % 12) + 12) % 12]; }
function noteName(m) { return noteShort(m) + (Math.floor(m / 12) - 1); }

const INTERVALS = {
  es: ['unísono', '2ª menor', '2ª mayor', '3ª menor', '3ª mayor', '4ª justa', '4ª aumentada', '5ª justa',
       '6ª menor', '6ª mayor', '7ª menor', '7ª mayor', '8ª justa', '9ª menor', '9ª mayor', '10ª menor',
       '10ª mayor', '11ª justa', '11ª aumentada', '12ª justa', '13ª menor', '13ª mayor', '14ª menor', '14ª mayor', '15ª justa'],
  en: ['unison', 'minor 2nd', 'major 2nd', 'minor 3rd', 'major 3rd', 'perfect 4th', 'augmented 4th', 'perfect 5th',
       'minor 6th', 'major 6th', 'minor 7th', 'major 7th', 'octave', 'minor 9th', 'major 9th', 'minor 10th',
       'major 10th', 'perfect 11th', 'augmented 11th', 'perfect 12th', 'minor 13th', 'major 13th', 'minor 14th', 'major 14th', 'double octave']
};
/* Intervalo en semitonos respecto de la referencia; negativo = por debajo (↓) */
function intervalName(semi) {
  const L = INTERVALS[S.lang] || INTERVALS.es, a = Math.abs(semi);
  const s = a < L.length ? L[a] : a + (S.lang === 'en' ? ' semitones' : ' semitonos');
  return (semi < 0 ? '↓ ' : '') + s;
}

/* Aplica textos a los elementos fijos del HTML (data-i18n / data-i18n-aria) */
function applyI18n() {
  document.documentElement.lang = S.lang;
  document.title = t('doc.title');
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-aria]').forEach(el => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
}
