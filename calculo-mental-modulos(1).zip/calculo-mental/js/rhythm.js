/* ===== rhythm.js — patrones de ritmo por cifra: parser y dibujo SVG ===== */
/* Sintaxis de un patrón:
     x = golpe · X = golpe con acento · - = silencio
     Los signos de un grupo se reparten su tramo en partes iguales:  xxx = tresillo
     La coma divide el pulso en tramos iguales:  xxx,xxxx = tresillo de semicorcheas + 4 fusas
     El espacio agrega otro pulso:  x xx = dura dos negras
   Un pulso entero en silencio se marca con un golpe sordo (ver audio.js). */
const RHY_MAX_BEATS = 4, RHY_MAX_SLOTS = 16;

function normRhythm(s) {
  return String(s == null ? '' : s).trim().replace(/\s*,\s*/g, ',').replace(/\s+/g, ' ');
}

/* Devuelve { src, beats, ev:[slot], restBeats:[i], struct:[{rest, segs:[{k, slots}]}] } o null */
function parseRhythm(src) {
  const s = normRhythm(src);
  if (!s || !/^[xX-]+(,[xX-]+)*( [xX-]+(,[xX-]+)*)*$/.test(s)) return null;
  const beats = s.split(' ');
  if (beats.length > RHY_MAX_BEATS) return null;
  const R = { src: s, beats: beats.length, ev: [], restBeats: [], struct: [] };
  for (let bi = 0; bi < beats.length; bi++) {
    const segs = beats[bi].split(','), segLen = 1 / segs.length;
    const B = { rest: true, segs: [] };
    for (let si = 0; si < segs.length; si++) {
      const ch = segs[si];
      if (ch.length > RHY_MAX_SLOTS) return null;
      const dur = segLen / ch.length, SG = { k: ch.length, slots: [] };
      for (let ci = 0; ci < ch.length; ci++) {
        const note = ch[ci] !== '-';
        const sl = { t: bi + si * segLen + ci * dur, dur, note, acc: ch[ci] === 'X', down: si === 0 && ci === 0 };
        SG.slots.push(sl);
        if (note) { B.rest = false; R.ev.push(sl); }
      }
      B.segs.push(SG);
    }
    if (B.rest) R.restBeats.push(bi);
    R.struct.push(B);
  }
  return R;
}

/* Ritmo vigente de la cifra d (si el guardado es inválido, el de fábrica) */
function rhythmOf(d) { return parseRhythm(S.rhythms[d]) || parseRhythm(DEFAULT_RHYTHMS[d]); }

/* Dibujo en notación simplificada: cabezas, plicas, barras (1 = corchea, 2 = semi, 3 = fusa),
   número de grupo irregular arriba y silencio de negra para el pulso vacío. Color = currentColor. */
function rhythmSVG(src) {
  const R = typeof src === 'string' ? parseRhythm(src) : src;
  if (!R) return '';
  const BW = 36, H = 28, HY = 23, ST = 7, BG = 3, BT = 2;
  const lev = d => d > 0.999 ? 0 : Math.floor(Math.log2(1 / d) + 1e-6);
  const pow2 = n => (n & (n - 1)) === 0;
  const f = n => n.toFixed(1);
  let g = '';
  R.struct.forEach((beat, bi) => {
    const x0 = bi * BW + 3, span = BW - 6;
    const X = sl => x0 + (sl.t - bi + sl.dur / 2) * span - 1;   // centro de su tramo
    if (beat.rest) {
      const x = x0 + span / 2 - 3;
      g += `<path d="M${f(x)},5 l4.5,5.5 l-3.5,4 l4.5,5.5 c-4,-2 -6,0.5 -2.5,4.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/>`;
      return;
    }
    const notes = [];
    beat.segs.forEach((sg, si) => sg.slots.forEach((sl, ci) => {
      const x = X(sl);
      if (sl.note) {
        notes.push({ x, l: lev(sl.dur), si, ci });
        g += `<ellipse cx="${f(x)}" cy="${HY}" rx="2.5" ry="1.8" transform="rotate(-20 ${f(x)} ${HY})" fill="currentColor"/>`;
        g += `<line x1="${f(x + 2.2)}" y1="${HY - 0.5}" x2="${f(x + 2.2)}" y2="${ST}" stroke="currentColor" stroke-width="0.9"/>`;
        if (sl.acc) g += `<path d="M${f(x - 2)},25.3 l4,1.1 l-4,1.1" fill="none" stroke="currentColor" stroke-width="0.7"/>`;
      } else {
        g += `<circle cx="${f(x)}" cy="14" r="1.1" fill="currentColor"/><line x1="${f(x + 2)}" y1="13" x2="${f(x - 0.5)}" y2="21" stroke="currentColor" stroke-width="0.9"/>`;
      }
    }));
    const sx = n => n.x + 2.2;
    const bar = (a, b, L) => `<rect x="${f(a)}" y="${ST + (L - 1) * BG}" width="${f(Math.max(0.9, b - a + 0.45))}" height="${BT}" fill="currentColor"/>`;
    if (notes.length === 1 && notes[0].l >= 1) {
      const n = notes[0];
      for (let k = 0; k < n.l; k++) g += `<path d="M${f(sx(n))},${ST + k * BG} q1,3.5 4.5,5.5" fill="none" stroke="currentColor" stroke-width="1.2"/>`;
    } else if (notes.length >= 2 && notes.every(n => n.l >= 1)) {
      g += bar(sx(notes[0]), sx(notes[notes.length - 1]), 1);
      const maxL = Math.max(...notes.map(n => n.l)), last = notes[notes.length - 1];
      for (let L = 2; L <= maxL; L++) {
        beat.segs.forEach((sg, si) => {
          let run = [];
          const flush = () => {
            if (run.length >= 2) g += bar(sx(run[0]), sx(run[run.length - 1]), L);
            else if (run.length === 1) { const a = sx(run[0]); g += run[0] === last ? bar(a - 3.5, a, L) : bar(a, a + 3.5, L); }
            run = [];
          };
          sg.slots.forEach((sl, ci) => {
            const n = notes.find(q => q.si === si && q.ci === ci);
            if (n && n.l >= L) run.push(n); else flush();
          });
          flush();
        });
      }
    }
    const nums = [];
    beat.segs.forEach((sg, si) => {
      if (pow2(sg.k)) return;
      const a = X(sg.slots[0]), b = X(sg.slots[sg.k - 1]);
      nums.push([(a + b) / 2 + 2.2, sg.k]);
    });
    if (!nums.length && !pow2(beat.segs.length) && notes.length)
      nums.push([(sx(notes[0]) + sx(notes[notes.length - 1])) / 2, beat.segs.length]);
    nums.forEach(([x, n]) => {
      g += `<text x="${f(x)}" y="5" font-size="6.5" font-weight="700" font-family="system-ui,sans-serif" text-anchor="middle" fill="currentColor">${n}</text>`;
    });
  });
  return `<svg viewBox="0 0 ${R.beats * BW} ${H}" aria-hidden="true">${g}</svg>`;
}
