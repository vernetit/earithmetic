/* ===== main.js — arranque ===== */
(function init() {
  applyI18n();
  bindRefKeys();
  buildKeys();
  bindGame();
  bindSettings();
  // navegación por data-go (delegada, sirve para botones creados dinámicamente)
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-go]'); if (!b) return;
    show(b.dataset.go);
  });
  $('#imp-file').addEventListener('change', e => {
    const f = e.target.files && e.target.files[0];
    if (f) importJSON(f);
    e.target.value = '';
  });
  // desbloquear audio en el primer toque (requisito de los navegadores móviles)
  const unlock = () => { audioInit(); window.removeEventListener('pointerdown', unlock); };
  window.addEventListener('pointerdown', unlock);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && AC && AC.state === 'suspended') AC.resume(); });
  show('home');
})();
