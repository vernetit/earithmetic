/* ===== ui-help.js — pantalla "Cómo se juega" (con las tablas de notas y ritmos vigentes) ===== */
function notesTableHTML() {
  let h = `<table class="help-tbl"><tr><th>${t('t.digit')}</th><th>${t('t.note')}</th><th>${t('t.interval')}</th></tr>`;
  h += `<tr><td>ref</td><td><b>${noteName(S.refMidi)}</b></td><td>—</td></tr>`;
  for (let d = 0; d <= 9; d++) {
    const m = S.digitMidi[d];
    h += `<tr><td><b>${d}</b></td><td>${noteName(m)}</td><td>${intervalName(m - S.refMidi)}</td></tr>`;
  }
  return h + '</table>';
}

function rhythmTableHTML() {
  let h = `<table class="help-tbl"><tr><th>${t('t.digit')}</th><th>${t('t.rhythm')}</th><th>${t('t.code')}</th><th>${t('t.name')}</th></tr>`;
  for (let d = 0; d <= 9; d++) {
    const R = rhythmOf(d);
    const name = R.src === normRhythm(DEFAULT_RHYTHMS[d]) ? t('rn.' + d) : t('t.custom');
    h += `<tr><td><b>${d}</b></td><td><span class="rg">${rhythmSVG(R)}</span></td><td><code>${R.src}</code></td><td>${name}</td></tr>`;
  }
  return h + '</table>';
}

function renderHelp() {
  $('#help-body').innerHTML = t('help.body', {
    notes: notesTableHTML(),
    rhythms: rhythmTableHTML(),
    bpm: S.bpmRit,
    count: S.countIn
  });
}
