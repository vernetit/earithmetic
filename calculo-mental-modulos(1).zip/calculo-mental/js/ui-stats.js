/* ===== ui-stats.js — estadísticas por modo con SVG propio, tablas, exportar/importar ===== */
let STATS_SM = 'notes';   // modo que se está mirando (arranca en el modo actual)

function svgLine(vals, levels) {
  if (vals.length < 2) return `<p class="mut">${t('s.notEnough')}</p>`;
  const w = 340, h = 180, pl = 38, pr = 8, pt = 8, pb = 14;
  const ym = Math.max(1, Math.ceil(Math.max(...vals) + 0.3));
  const X = i => pl + (w - pl - pr) * i / (vals.length - 1);
  const Y = v => pt + (h - pt - pb) * (1 - v / ym);
  const step = Math.max(1, Math.ceil(ym / 6));
  let g = '';
  for (let k = 0; k <= ym; k += step)
    g += `<line class="gl" x1="${pl}" x2="${w - pr}" y1="${Y(k).toFixed(1)}" y2="${Y(k).toFixed(1)}"/>` +
         `<text class="tx" x="${pl - 4}" y="${(Y(k) + 3.5).toFixed(1)}" text-anchor="end">${levels[k] ? levels[k].n : ''}</text>`;
  const pts = vals.map((v, i) => X(i).toFixed(1) + ',' + Y(v).toFixed(1)).join(' ');
  return `<svg class="chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="${t('s.ratingT')}">${g}<polyline class="ln" points="${pts}"/></svg>`;
}

function svgBars(rows) {
  if (!rows.length) return `<p class="mut">${t('s.noData')}</p>`;
  const w = 340, rh = 18, pl = 40, pr = 62, h = rows.length * rh + 4;
  let g = '';
  rows.forEach((r, i) => {
    const y = i * rh + 2, bw = (w - pl - pr) * r.v;
    g += `<text class="tx" x="${pl - 6}" y="${y + 12}" text-anchor="end">${r.label}</text>` +
         `<rect class="bk" x="${pl}" y="${y + 3}" width="${w - pl - pr}" height="${rh - 7}" rx="3"/>` +
         `<rect class="bv" x="${pl}" y="${y + 3}" width="${bw.toFixed(1)}" height="${rh - 7}" rx="3"/>` +
         `<text class="tx" x="${w - pr + 4}" y="${y + 12}">${Math.round(r.v * 100)}% (${r.n})</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="${t('s.barsT')}">${g}</svg>`;
}

function renderStats() {
  const levels = DISCIPLINES.mul.levels;
  const sm = STATS_SM === 'rhythm' ? 'r' : 'n';
  const H = HIST.filter(x => x.d === 'mul' && (x.sm || 'n') === sm);
  const el = $('#stats-body');
  const seg = segHTML('st-mode', [['notes', t('mode.notes')], ['rhythm', t('mode.rhythm')]], STATS_SM, true);
  const bindSeg = () => onSeg('st-mode', v => { STATS_SM = v; renderStats(); });
  if (!H.length) {
    el.innerHTML = seg + `<div class="card"><p class="mut">${t('s.none')}</p></div>` + ioButtons();
    bindSeg(); bindIO(); return;
  }
  const okN = H.filter(x => x.ok).length;
  const totS = H.reduce((s, x) => s + (x.s || 0), 0);
  const ratingSeries = H.filter(x => x.m === 'adapt').slice(-400).map(x => x.r);

  const by = {};
  H.forEach(x => { (by[x.l] = by[x.l] || []).push(x); });
  const lvIdx = Object.keys(by).map(Number).sort((a, b) => a - b);
  const bars = lvIdx.map(i => ({ label: levels[i].n, v: by[i].filter(x => x.ok).length / by[i].length, n: by[i].length }));
  const rows = lvIdx.map(i => {
    const A = by[i], okT = A.filter(x => x.ok).map(x => x.s);
    return `<tr><td>${levels[i].n}</td><td>${A.length}</td><td>${pct(okT.length / A.length)}</td>
      <td>${fmtS(median(okT))}</td><td>${okT.length ? fmtS(Math.min(...okT)) : '–'}</td><td>${levels[i].t} s</td></tr>`;
  }).join('');
  const recent = H.slice(-20).reverse().map(x => `<tr><td>${fmtDate(x.ts)}</td><td>${x.q}</td>
      <td class="${x.ok ? 'ok' : 'bad'}">${x.p ? t('s.passed') : (x.ok ? '✔' : '✘ ' + (x.u || '–'))}</td><td>${x.a}</td><td>${fmtS(x.s)}</td></tr>`).join('');

  el.innerHTML = seg + `
    <div class="card kpis">
      <div><b>${H.length}</b><span>${t('s.problems')}</span></div>
      <div><b>${pct(okN / H.length)}</b><span>${t('s.correct')}</span></div>
      <div><b>${fmtS(totS)}</b><span>${t('s.time')}</span></div>
    </div>
    <div class="card"><h2>${t('s.ratingT')}</h2>${svgLine(ratingSeries, levels)}</div>
    <div class="card"><h2>${t('s.barsT')}</h2>${svgBars(bars)}</div>
    <div class="card tscroll"><h2>${t('s.byLevel')}</h2>
      <table><tr><th>${t('s.thLevel')}</th><th>N</th><th>${t('s.thRight')}</th><th>${t('s.thMedian')}</th><th>${t('s.thBest')}</th><th>${t('s.thTarget')}</th></tr>${rows}</table></div>
    <div class="card tscroll"><h2>${t('s.last20')}</h2>
      <table><tr><th>${t('s.thDate')}</th><th>${t('s.thProb')}</th><th>${t('s.thYou')}</th><th>${t('s.thAns')}</th><th>${t('s.thTime')}</th></tr>${recent}</table></div>
    ${ioButtons()}`;
  bindSeg(); bindIO();
}

function ioButtons() {
  return `<div class="btns">
    <button class="btn" id="st-exp">${t('s.exp')}</button>
    <button class="btn" id="st-imp">${t('s.imp')}</button>
    <button class="btn" id="st-del">${t('s.del')}</button></div>`;
}

function bindIO() {
  $('#st-exp').onclick = exportJSON;
  $('#st-imp').onclick = () => $('#imp-file').click();
  $('#st-del').onclick = () => {
    if (!confirm(t('s.delConfirm'))) return;
    HIST = []; RATINGS = { mul: 0, mul_r: 0 }; saveHist(); saveRatings();
    store.del('lastSession'); store.del('lastSession_r');
    renderStats();
  };
}

function exportJSON() {
  const data = { app: 'calculo-mental-notas', v: 2, exported: new Date().toISOString(), settings: S, ratings: RATINGS, hist: HIST };
  const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
  const a = document.createElement('a');
  const d = new Date();
  a.href = URL.createObjectURL(blob);
  a.download = `calculo-mental-notas-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/* Acepta exportaciones v1 (solo notas) y v2 (notas + ritmo) */
function importJSON(file) {
  const fr = new FileReader();
  fr.onload = () => {
    try {
      const d = JSON.parse(fr.result);
      if (!d || !Array.isArray(d.hist)) throw new Error('formato');
      if (!confirm(t('s.impConfirm', { n: d.hist.length }))) return;
      HIST = d.hist; saveHist();
      if (d.ratings && typeof d.ratings.mul === 'number') { RATINGS = Object.assign({ mul: 0, mul_r: 0 }, d.ratings); saveRatings(); }
      if (d.settings) { S = normSettings(d.settings); saveSettings(); setVolume(S.vol); applyI18n(); }
      renderStats();
    } catch (e) { alert(t('s.impBad')); }
  };
  fr.readAsText(file);
}
