/* ===== audio.js — síntesis local con Web Audio API + capa de "modo de sonido" ===== */
/* Las notas son configurables (S.refMidi, S.digitMidi). Por defecto: referencia La3 = 220 Hz
   y cada dígito d suena d+2 semitonos arriba. */
const midiF = m => 440 * Math.pow(2, (m - 69) / 12);
function noteOf(d) { const m = S.digitMidi[d]; return { m, f: midiF(m) }; }
const isRhy = () => S.sound === 'rhythm';

let AC = null, MASTER = null, CUR_SEQ = null, NOISE = null, PREV = null;

function audioInit() {
  if (AC) { if (AC.state === 'suspended') AC.resume(); return AC; }
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  AC = new Ctx();
  const comp = AC.createDynamicsCompressor();
  comp.threshold.value = -16; comp.knee.value = 12; comp.ratio.value = 4;
  comp.attack.value = 0.003; comp.release.value = 0.2;
  MASTER = AC.createGain();
  MASTER.gain.value = S.vol;
  MASTER.connect(comp); comp.connect(AC.destination);
  return AC;
}
function setVolume(v) { if (MASTER) MASTER.gain.setTargetAtTime(v, AC.currentTime, 0.02); }
function noiseBuf(ac) {
  if (NOISE) return NOISE;
  const n = Math.floor(ac.sampleRate * 0.25), b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  return (NOISE = b);
}

/* ---------- timbres ---------- */
/* Piano eléctrico suave: fundamental + armónicos que decaen rápido, ADSR corta.
   Cada nota tiene su propio nodo de ganancia que arranca en 0 → sin clics al repetir. */
const PARTIALS = [
  { type: 'sine',     m: 1,    a: 1.00, dec: 0 },
  { type: 'sine',     m: 2,    a: 0.30, dec: 0.12 },
  { type: 'triangle', m: 1,    a: 0.14, dec: 0.4 },
  { type: 'sine',     m: 3.01, a: 0.07, dec: 0.05 }
];
function playFreq(f, when, durMs, vel, dest) {
  const ac = audioInit(); if (!ac) return;
  const t0 = Math.max(when || 0, ac.currentTime + 0.005);
  const dur = Math.max(0.08, (durMs || S.noteMs) / 1000);
  const peak = 0.30 * (vel == null ? 1 : vel);
  const env = ac.createGain();
  env.gain.setValueAtTime(0, t0);
  env.gain.linearRampToValueAtTime(peak, t0 + 0.007);           // ataque
  env.gain.setTargetAtTime(peak * 0.38, t0 + 0.007, 0.16);      // decaimiento → sostenido
  env.gain.setTargetAtTime(0, t0 + dur, 0.07);                  // relajación
  const lp = ac.createBiquadFilter();
  lp.type = 'lowpass'; lp.frequency.value = Math.min(6000, f * 9); lp.Q.value = 0.3;
  env.connect(lp); lp.connect(dest || MASTER);
  const tEnd = t0 + dur + 0.6;
  PARTIALS.forEach(p => {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = p.type; o.frequency.value = f * p.m;
    g.gain.setValueAtTime(p.a, t0);
    if (p.dec) g.gain.setTargetAtTime(p.a * 0.08, t0, p.dec);
    o.connect(g); g.connect(env);
    o.start(t0); o.stop(tEnd);
    o.onended = () => { try { o.disconnect(); g.disconnect(); } catch (e) {} };
  });
  setTimeout(() => { try { env.disconnect(); lp.disconnect(); } catch (e) {} }, (tEnd - ac.currentTime) * 1000 + 200);
}
function playDigit(d, when, durMs, dest) { playFreq(noteOf(d).f, when, durMs, 1, dest); }
function playBase(when, durMs, dest) { playFreq(midiF(S.refMidi), when, durMs, 1, dest); }

/* Golpe de ritmo tipo bloque de madera. Si f > 0, en cambio toca esa nota corta. */
function playHit(when, acc, dest, f) {
  const ac = audioInit(); if (!ac) return;
  const t0 = Math.max(when || 0, ac.currentTime + 0.005);
  const v = acc ? 1 : 0.5;
  if (f) { playFreq(f, t0, 150, v, dest); return; }
  const o = ac.createOscillator(), o2 = ac.createOscillator(), g = ac.createGain(), g2 = ac.createGain();
  o.type = 'triangle';
  o.frequency.setValueAtTime(acc ? 1120 : 1050, t0);
  o.frequency.exponentialRampToValueAtTime(760, t0 + 0.06);
  o2.type = 'sine'; o2.frequency.value = 2630;
  g2.gain.setValueAtTime(0.25, t0); g2.gain.exponentialRampToValueAtTime(0.001, t0 + 0.02);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(0.5 * v, t0 + 0.002);
  g.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.085);
  o.connect(g); o2.connect(g2); g2.connect(g); g.connect(dest || MASTER);
  o.start(t0); o2.start(t0); o.stop(t0 + 0.1); o2.stop(t0 + 0.1);
  o.onended = () => { try { o.disconnect(); o2.disconnect(); g.disconnect(); g2.disconnect(); } catch (e) {} };
}

/* Silencio de pulso entero: golpe sordo y grave, distinto de los golpes */
function playRestMark(when, dest) {
  const ac = audioInit(); if (!ac) return;
  const t0 = Math.max(when || 0, ac.currentTime + 0.005);
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine';
  o.frequency.setValueAtTime(170, t0); o.frequency.exponentialRampToValueAtTime(70, t0 + 0.15);
  g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(0.55, t0 + 0.004);
  g.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.2);
  const n = ac.createBufferSource(), lp = ac.createBiquadFilter(), gn = ac.createGain();
  n.buffer = noiseBuf(ac); lp.type = 'lowpass'; lp.frequency.value = 500;
  gn.gain.setValueAtTime(0.18, t0); gn.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.07);
  o.connect(g); n.connect(lp); lp.connect(gn); gn.connect(g); g.connect(dest || MASTER);
  o.start(t0); n.start(t0); o.stop(t0 + 0.22); n.stop(t0 + 0.1);
  o.onended = () => { try { o.disconnect(); n.disconnect(); lp.disconnect(); gn.disconnect(); g.disconnect(); } catch (e) {} };
}

/* Click de conteo / metrónomo: ruido agudo muy corto (soft = metrónomo suave) */
function playClick(when, acc, dest, soft) {
  const ac = audioInit(); if (!ac) return;
  const t0 = Math.max(when || 0, ac.currentTime + 0.005);
  const src = ac.createBufferSource(), hp = ac.createBiquadFilter(), g = ac.createGain();
  src.buffer = noiseBuf(ac); hp.type = 'highpass'; hp.frequency.value = 4500;
  const pk = (soft ? 0.1 : 0.35) * (acc ? 1.5 : 1);
  g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(pk, t0 + 0.001);
  g.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.04);
  src.connect(hp); hp.connect(g); g.connect(dest || MASTER);
  src.start(t0); src.stop(t0 + 0.06);
  src.onended = () => { try { src.disconnect(); hp.disconnect(); g.disconnect(); } catch (e) {} };
}

/* Programa el ritmo R desde t (s) con pulso beat (s). f > 0 = golpes con nota. */
function schedRhythm(R, t, beat, dest, f) {
  R.ev.forEach(e => playHit(t + e.t * beat, e.acc || (S.accentBeat && e.down), dest, f));
  R.restBeats.forEach(b => playRestMark(t + b * beat, dest));
  if (S.beatClick) for (let b = 0; b < R.beats; b++) playClick(t + b * beat, false, dest, true);
}

/* ---------- secuencias ---------- */
/* items = [{ u: unidades de tiempo (def. 1), fn: (t, bus, unitSec) => void | null, id? }]
   fn null = silencio. Usa un bus propio para poder cortarla. Devuelve la duración total en ms. */
function playSeq(items, unitMs, onStep) {
  stopSeq();
  const ac = audioInit(); if (!ac) return 0;
  const bus = ac.createGain(); bus.gain.value = 1; bus.connect(MASTER);
  const seq = { bus, timers: [] };
  CUR_SEQ = seq;
  const unit = unitMs / 1000, start = ac.currentTime + 0.06;
  let t = start;
  items.forEach(it => {
    const u = it.u == null ? 1 : it.u;
    if (it.fn) {
      it.fn(t, bus, unit);
      if (onStep) seq.timers.push(setTimeout(() => onStep(it, u * unitMs), (t - ac.currentTime) * 1000));
    }
    t += u * unit;
  });
  const total = (t - start) * 1000;
  seq.timers.push(setTimeout(() => { if (CUR_SEQ === seq) CUR_SEQ = null; }, total + 800));
  return total;
}
function stopSeq() {
  if (!CUR_SEQ) return;
  const s = CUR_SEQ; CUR_SEQ = null;
  s.timers.forEach(clearTimeout);
  try { s.bus.gain.setTargetAtTime(0, AC.currentTime, 0.02); setTimeout(() => { try { s.bus.disconnect(); } catch (e) {} }, 300); } catch (e) {}
}

/* ---------- capa de modo: lo que el juego usa sin saber si es notas o ritmo ---------- */
/* Unidad de tiempo de la secuencia: en notas, una nota; en ritmo, un pulso de negra */
function unitMs() { return 60000 / (isRhy() ? S.bpmRit : S.bpmMel); }
const rhyPitch = d => S.rhythmPitch ? noteOf(d).f : 0;

/* Ítem de secuencia para la cifra d */
function digitItem(d, id) {
  if (isRhy()) {
    const R = rhythmOf(d);
    return { u: R.beats, id, d, fn: (t, bus, unit) => schedRhythm(R, t, unit, bus, rhyPitch(d)) };
  }
  return { u: 1, id, d, fn: (t, bus, unit) => playDigit(d, t, Math.min(S.noteMs, unit * 1700), bus) };
}
/* Lo que suena antes de la cuenta: la nota de referencia + silencio, o el conteo */
function refItems() {
  if (isRhy()) {
    const a = [];
    for (let i = 0; i < +S.countIn; i++) a.push({ u: 1, fn: (t, bus) => playClick(t, i === 0, bus) });
    return a;
  }
  return S.playBase ? [{ u: 1, fn: (t, bus, unit) => playBase(t, Math.min(S.noteMs, unit * 1700), bus) }, { u: 1, fn: null }] : [];
}
/* Separación entre el factor de arriba y el de abajo: 2 unidades sin sonido */
function sepItems() { return [{ u: 1, fn: null }, { u: 1, fn: null }]; }

/* Vista previa de un ritmo suelto: corta la anterior para que no se encimen al escribir rápido */
function previewBus() {
  const ac = audioInit(); if (!ac) return null;
  if (PREV) {
    const p = PREV;
    try { p.gain.setTargetAtTime(0, ac.currentTime, 0.008); } catch (e) {}
    setTimeout(() => { try { p.disconnect(); } catch (e) {} }, 150);
  }
  const bus = ac.createGain(); bus.connect(MASTER); PREV = bus;
  return bus;
}
function previewRhythm(R, f) {
  if (!R) return;
  const bus = previewBus(); if (!bus) return;
  const beat = 60 / S.bpmRit;
  schedRhythm(R, AC.currentTime + 0.02, beat, bus, f);
  setTimeout(() => { if (PREV === bus) PREV = null; try { bus.disconnect(); } catch (e) {} }, R.beats * beat * 1000 + 1200);
}
/* Cifra suelta (teclas, pad, casilleros) en el modo actual */
function playDigitNow(d) {
  if (isRhy()) previewRhythm(rhythmOf(d), rhyPitch(d));
  else playDigit(d);
}
/* Botón de referencia: la nota de referencia, o 4 clicks al tempo del ritmo */
function playRefNow() {
  if (!isRhy()) { playBase(); return; }
  const bus = previewBus(); if (!bus) return;
  const beat = 60 / S.bpmRit;
  for (let i = 0; i < 4; i++) playClick(AC.currentTime + 0.02 + i * beat, i === 0, bus);
  setTimeout(() => { if (PREV === bus) PREV = null; try { bus.disconnect(); } catch (e) {} }, 4 * beat * 1000 + 800);
}

/* Sonidos de corrección (fuera de la escala de los dígitos, una octava arriba) */
function sfx(ok) {
  const ac = audioInit(); if (!ac) return;
  const t = ac.currentTime + 0.02;
  if (ok) { playFreq(659.25, t, 120, 0.45); playFreq(880, t + 0.1, 220, 0.45); }
  else    { playFreq(196.0, t, 160, 0.5);   playFreq(185.0, t + 0.15, 280, 0.5); }
}
