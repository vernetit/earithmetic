/* ===== ui-settings.js — configuración a partir de la tabla SETTINGS_UI + editores de notas y ritmos ===== */
function renderSettings() {
  $('#set-body').innerHTML = SETTINGS_UI.map(it => {
    if (it.sec) return `<h3>${t(it.sec)}</h3>`;
    if (it.type === 'notesMap') return notesMapHTML();
    if (it.type === 'rhyMap') return rhyMapHTML();
    const v = S[it.k], lab = t(it.label);
    if (it.type === 'bool')
      return `<label class="row"><span>${lab}</span><input type="checkbox" data-k="${it.k}" ${v ? 'checked' : ''}></label>`;
    if (it.type === 'range')
      return `<label class="row col"><span>${lab}: <b id="sv-${it.k}">${it.fmt ? it.fmt(v) : v}</b></span>
        <input type="range" data-k="${it.k}" min="${it.min}" max="${it.max}" step="${it.step}" value="${v}"></label>`;
    if (it.type === 'select')
      return `<label class="row"><span>${lab}</span><select data-k="${it.k}">${it.opts.map(([val, ol]) =>
        `<option value="${val}" ${String(val) === String(v) ? 'selected' : ''}>${t(ol)}</option>`).join('')}</select></label>`;
    return '';
  }).join('');
}

/* ---------- notas por cifra ---------- */
function midiOptions(sel) {
  let h = '';
  for (let m = MIDI_MIN; m <= MIDI_MAX; m++) h += `<option value="${m}" ${m === sel ? 'selected' : ''}>${noteName(m)}</option>`;
  return h;
}
function dupWarn() {
  const by = {};
  S.digitMidi.forEach((m, d) => { (by[m] = by[m] || []).push(d); });
  const g = Object.values(by).filter(a => a.length > 1).map(a => a.join(' = '));
  return g.length ? t('set.dup', { list: g.join(' · ') }) : '';
}
function notesMapHTML() {
  let h = `<div class="mrow"><span class="md">ref</span><select data-nm="ref">${midiOptions(S.refMidi)}</select>` +
          `<span class="iv"></span><button type="button" class="btn sm pl" data-pn="ref">▶</button></div>`;
  for (let d = 0; d <= 9; d++)
    h += `<div class="mrow"><span class="md">${d}</span><select data-nm="${d}">${midiOptions(S.digitMidi[d])}</select>` +
         `<span class="iv">${intervalName(S.digitMidi[d] - S.refMidi)}</span>` +
         `<button type="button" class="btn sm pl" data-pn="${d}">▶</button></div>`;
  return h + `<div class="warn">${dupWarn()}</div>` +
    `<div class="btns"><button type="button" class="btn sm" id="nm-reset">${t('set.notesReset')}</button></div>`;
}

/* ---------- ritmos por cifra ---------- */
function rhyMapHTML() {
  let h = `<p class="mut small">${t('set.rhyHelp')}</p>`;
  for (let d = 0; d <= 9; d++) {
    const R = rhythmOf(d);
    h += `<div class="mrow"><span class="md">${d}</span>` +
         `<input type="text" data-rh="${d}" value="${R.src}" autocomplete="off" autocapitalize="off" spellcheck="false" inputmode="text">` +
         `<span class="rg" id="rg-${d}">${rhythmSVG(R)}</span>` +
         `<button type="button" class="btn sm pl" data-pr="${d}">▶</button></div>`;
  }
  return h + `<div class="btns"><button type="button" class="btn sm" id="rh-reset">${t('set.rhyReset')}</button></div>`;
}

function bindSettings() {
  const body = $('#set-body');
  const onChange = e => {
    // selects de notas
    const nm = e.target.closest('[data-nm]');
    if (nm) {
      if (e.type !== 'change') return;
      const m = +nm.value;
      if (nm.dataset.nm === 'ref') S.refMidi = m; else S.digitMidi[+nm.dataset.nm] = m;
      saveSettings(); playFreq(midiF(m)); renderSettings();
      return;
    }
    // patrones de ritmo: se guardan solo si son válidos
    const rh = e.target.closest('[data-rh]');
    if (rh) {
      const d = +rh.dataset.rh, R = parseRhythm(rh.value);
      rh.classList.toggle('bad', !R);
      if (R) { S.rhythms[d] = R.src; saveSettings(); $('#rg-' + d).innerHTML = rhythmSVG(R); }
      if (e.type === 'change' && !R) { rh.value = rhythmOf(d).src; rh.classList.remove('bad'); }
      return;
    }
    const inp = e.target.closest('[data-k]'); if (!inp) return;
    const k = inp.dataset.k, it = SETTINGS_UI.find(x => x.k === k);
    let v;
    if (it.type === 'bool') v = inp.checked;
    else if (it.str) v = inp.value;
    else v = +inp.value;
    S[k] = v; saveSettings();
    if (it.type === 'range') { const b = document.getElementById('sv-' + k); if (b) b.textContent = it.fmt ? it.fmt(v) : v; }
    if (k === 'vol') setVolume(v);
    if (k === 'lang') { applyI18n(); renderSettings(); }
  };
  body.addEventListener('input', onChange);
  body.addEventListener('change', onChange);
  body.addEventListener('click', e => {
    const pn = e.target.closest('[data-pn]');
    if (pn) { playFreq(midiF(pn.dataset.pn === 'ref' ? S.refMidi : S.digitMidi[+pn.dataset.pn])); return; }
    const pr = e.target.closest('[data-pr]');
    if (pr) { const d = +pr.dataset.pr; previewRhythm(rhythmOf(d), S.rhythmPitch ? noteOf(d).f : 0); return; }
    if (e.target.closest('#nm-reset')) { S.refMidi = DEFAULT_REF_MIDI; S.digitMidi = DEFAULT_DIGIT_MIDI.slice(); saveSettings(); renderSettings(); return; }
    if (e.target.closest('#rh-reset')) { S.rhythms = DEFAULT_RHYTHMS.slice(); saveSettings(); renderSettings(); }
  });
  // Probar sonido: referencia + cifras 0…9 en el modo actual
  $('#set-test').onclick = () => {
    audioInit();
    const items = refItems();
    for (let d = 0; d <= 9; d++) items.push(digitItem(d));
    playSeq(items, isRhy() ? unitMs() : Math.max(220, unitMs() * 0.6));
  };
  $('#set-reset').onclick = () => {
    if (!confirm(t('set.resetConfirm'))) return;
    S = Object.assign(freshDefaults(), { lang: S.lang, sound: S.sound });
    saveSettings(); setVolume(S.vol); renderSettings();
  };
}
