/* ===== ui-common.js — utilidades de interfaz ===== */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

function show(id) {
  $$('.scr').forEach(e => e.classList.toggle('on', e.id === 'scr-' + id));
  window.scrollTo(0, 0);
  if (id === 'home') renderHome();
  if (id === 'stats') { STATS_SM = S.sound; renderStats(); }
  if (id === 'help') renderHelp();
  if (id === 'settings') renderSettings();
}

function flash(el, ms) {
  if (!el) return;
  el.classList.add('fl');
  setTimeout(() => el.classList.remove('fl'), ms || 160);
}
function hl(el, ms) {
  if (!el) return;
  el.classList.add('hl');
  clearTimeout(el._hlT);
  el._hlT = setTimeout(() => el.classList.remove('hl'), ms || 320);
}
function fmtS(s) {
  if (s == null || isNaN(s)) return '–';
  return s < 60 ? s.toFixed(1) + ' s' : Math.floor(s / 60) + 'm ' + String(Math.round(s % 60)).padStart(2, '0') + 's';
}
function pct(x) { return isFinite(x) ? Math.round(x * 100) + '%' : '–'; }
function median(a) {
  if (!a.length) return NaN;
  const s = a.slice().sort((x, y) => x - y), m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
function fmtDate(ts) {
  const d = new Date(ts);
  const loc = t('locale');
  return d.toLocaleDateString(loc, { day: '2-digit', month: '2-digit' }) + ' ' +
         d.toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit', hour12: false });
}

/* Control segmentado: [[valor, texto], …] → botones con data-v; el activo lleva .on */
function segHTML(id, items, cur, big) {
  return `<div class="seg${big ? ' big' : ''}" id="${id}">` +
    items.map(([v, lab]) => `<button type="button" data-v="${v}" class="${v === cur ? 'on' : ''}">${lab}</button>`).join('') + '</div>';
}
function onSeg(id, fn) {
  const el = document.getElementById(id); if (!el) return;
  el.onclick = e => { const b = e.target.closest('[data-v]'); if (b) fn(b.dataset.v); };
}
