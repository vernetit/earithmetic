/* ===== storage.js — persistencia en localStorage (prefijo cmz.) y configuración ===== */
const LS_PREFIX = 'cmz.';
const store = {
  get(k, def) {
    try { const v = localStorage.getItem(LS_PREFIX + k); return v == null ? def : JSON.parse(v); }
    catch (e) { return def; }
  },
  set(k, v) { try { localStorage.setItem(LS_PREFIX + k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem(LS_PREFIX + k); } catch (e) {} }
};

/* Notas por defecto (MIDI): referencia La3 = 57; el dígito d = 59 + d (Si3 … Sol#4) */
const DEFAULT_REF_MIDI = 57;
const DEFAULT_DIGIT_MIDI = [59, 60, 61, 62, 63, 64, 65, 66, 67, 68];
const MIDI_MIN = 36, MIDI_MAX = 84;   // rango ofrecido en Configuración (Do2 … Do6)

/* Ritmos por defecto (un pulso de negra por cifra). Sintaxis en rhythm.js */
const DEFAULT_RHYTHMS = [
  '-',          // 0 silencio de negra (suena un golpe sordo)
  'x',          // 1 negra
  'xx',         // 2 dos corcheas
  'xxx',        // 3 tresillo de corcheas
  'xxxx',       // 4 cuatro semicorcheas
  'xxxxx',      // 5 quintillo
  'xxxxxx',     // 6 seisillo de semicorcheas
  'xxxxxxx',    // 7 septillo
  'xxxxxxxx',   // 8 ocho fusas
  'xxx,xxxx'    // 9 tresillo de semicorcheas + 4 fusas
];

/* Valores por defecto de la configuración */
const DEFAULTS = {
  lang: 'es',        // 'es' | 'en'
  sound: 'notes',    // 'notes' | 'rhythm'  (modo de sonido)
  vol: 0.7,          // volumen general 0..1
  noteMs: 700,       // duración de una nota suelta
  bpmMel: 125,       // notas por minuto al tocar la cuenta en modo notas
  autoPlay: true,    // tocar la cuenta al empezar cada problema
  playBase: true,    // modo notas: tocar la nota de referencia antes de la cuenta
  keySound: true,    // sonar la cifra al escribirla
  fbSound: true,     // sonidito de acierto / error
  bpmRit: 60,        // pulsos (negras) por minuto en modo ritmo
  countIn: 2,        // modo ritmo: clicks de conteo antes de la cuenta
  accentBeat: true,  // modo ritmo: acentuar el primer golpe de cada pulso
  beatClick: false,  // modo ritmo: click suave en cada pulso
  rhythmPitch: false,// modo ritmo: cada golpe con la nota de su cifra
  refMidi: DEFAULT_REF_MIDI,
  digitMidi: DEFAULT_DIGIT_MIDI,
  rhythms: DEFAULT_RHYTHMS,
  padNums: false,    // mostrar números en el pad de la cuenta
  keyNums: false,    // mostrar números en el teclado de respuesta
  autoJudge: true,   // corregir solo al completar todas las casillas
  advanceMs: 1200,   // pausa tras acierto antes del próximo problema
  wrongWait: true,   // tras error, esperar "Seguir"
  sessionLen: 20     // problemas por sesión (0 = sin límite)
};

/* Tabla declarativa que dibuja renderSettings. label / sec / opts son claves de i18n. */
const SETTINGS_UI = [
  { sec: 'sec.general' },
  { k: 'lang', type: 'select', str: true, label: 'set.lang', opts: [['es', 'Español'], ['en', 'English']] },
  { k: 'sound', type: 'select', str: true, label: 'set.sound', opts: [['notes', 'mode.notes'], ['rhythm', 'mode.rhythm']] },
  { sec: 'sec.sound' },
  { k: 'vol', type: 'range', label: 'set.vol', min: 0, max: 1, step: 0.05, fmt: v => Math.round(v * 100) + '%' },
  { k: 'bpmMel', type: 'range', label: 'set.bpmMel', min: 40, max: 300, step: 5, fmt: v => v + ' bpm' },
  { k: 'noteMs', type: 'range', label: 'set.noteMs', min: 200, max: 1500, step: 50, fmt: v => v + ' ms' },
  { k: 'autoPlay', type: 'bool', label: 'set.autoPlay' },
  { k: 'playBase', type: 'bool', label: 'set.playBase' },
  { k: 'keySound', type: 'bool', label: 'set.keySound' },
  { k: 'fbSound', type: 'bool', label: 'set.fbSound' },
  { sec: 'sec.rhythm' },
  { k: 'bpmRit', type: 'range', label: 'set.bpmRit', min: 30, max: 200, step: 2, fmt: v => v + ' bpm' },
  { k: 'countIn', type: 'select', label: 'set.countIn', opts: [[0, '0'], [1, '1'], [2, '2'], [3, '3'], [4, '4']] },
  { k: 'accentBeat', type: 'bool', label: 'set.accentBeat' },
  { k: 'beatClick', type: 'bool', label: 'set.beatClick' },
  { k: 'rhythmPitch', type: 'bool', label: 'set.rhythmPitch' },
  { sec: 'sec.notesMap' },
  { type: 'notesMap' },
  { sec: 'sec.rhyMap' },
  { type: 'rhyMap' },
  { sec: 'sec.visual' },
  { k: 'padNums', type: 'bool', label: 'set.padNums' },
  { k: 'keyNums', type: 'bool', label: 'set.keyNums' },
  { sec: 'sec.game' },
  { k: 'autoJudge', type: 'bool', label: 'set.autoJudge' },
  { k: 'advanceMs', type: 'range', label: 'set.advanceMs', min: 300, max: 4000, step: 100, fmt: v => (v / 1000).toFixed(1) + ' s' },
  { k: 'wrongWait', type: 'bool', label: 'set.wrongWait' },
  { k: 'sessionLen', type: 'select', label: 'set.sessionLen', opts: [[10, '10'], [20, '20'], [30, '30'], [50, '50'], [0, 'opt.unlimited']] }
];

/* Copia limpia de los valores por defecto (los arrays no se comparten) */
function freshDefaults() {
  return Object.assign({}, DEFAULTS, { digitMidi: DEFAULT_DIGIT_MIDI.slice(), rhythms: DEFAULT_RHYTHMS.slice() });
}

/* Normaliza una configuración guardada o importada (migra versiones viejas) */
function normSettings(st) {
  st = (st && typeof st === 'object') ? st : {};
  const s = Object.assign(freshDefaults(), st);
  // v1 usaba seqGapMs (ms entre notas) → bpm
  if (st.seqGapMs && st.bpmMel == null) s.bpmMel = Math.max(40, Math.min(300, Math.round(60000 / st.seqGapMs / 5) * 5));
  delete s.seqGapMs;
  const okMidi = m => Number.isInteger(m) && m >= 24 && m <= 96;
  s.digitMidi = (Array.isArray(st.digitMidi) && st.digitMidi.length === 10 && st.digitMidi.every(okMidi))
    ? st.digitMidi.slice() : DEFAULT_DIGIT_MIDI.slice();
  if (!okMidi(s.refMidi)) s.refMidi = DEFAULT_REF_MIDI;
  s.rhythms = (Array.isArray(st.rhythms) && st.rhythms.length === 10)
    ? st.rhythms.map((r, i) => typeof r === 'string' && r.trim() ? r : DEFAULT_RHYTHMS[i]) : DEFAULT_RHYTHMS.slice();
  if (s.lang !== 'es' && s.lang !== 'en') s.lang = 'es';
  if (s.sound !== 'notes' && s.sound !== 'rhythm') s.sound = 'notes';
  return s;
}

let S = normSettings(store.get('settings', {}));
/* Un rating por modo de sonido: mul = notas, mul_r = ritmo */
let RATINGS = Object.assign({ mul: 0, mul_r: 0 }, store.get('ratings', {}));
let HIST = store.get('hist', []);
const HIST_MAX = 5000;

function saveSettings() { store.set('settings', S); }
function saveRatings() { store.set('ratings', RATINGS); }
function saveHist() {
  if (HIST.length > HIST_MAX) HIST = HIST.slice(-HIST_MAX);
  store.set('hist', HIST);
}
