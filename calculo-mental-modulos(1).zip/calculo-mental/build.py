"""Arma el HTML único pegando CSS y JS adentro de index.html, en el orden de carga."""
import re, sys, pathlib
root = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2])
html = (root / 'index.html').read_text(encoding='utf-8')
css = (root / 'css/styles.css').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="css/styles.css">', '<style>\n' + css + '\n</style>')
def inline(m):
    return '<script>\n' + (root / m.group(1)).read_text(encoding='utf-8') + '\n</script>'
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
out.write_text(html, encoding='utf-8')
print(out, len(html), 'bytes')
